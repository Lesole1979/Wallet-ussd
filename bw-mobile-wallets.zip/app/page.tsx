'use client';

import { useState, useEffect } from "react";
import { Phone, Info, Share2, Search, Download } from "lucide-react";
import Image from "next/image";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    }
  };

  const handleShare = async (e: React.MouseEvent, network: string, code: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    const text = `Use ${network} on BW Wallet Hub! Dial ${code} directly from your phone.`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${network} USSD Code`,
          text: text,
          url: window.location.href,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          console.error(err);
        }
      }
    } else {
      navigator.clipboard.writeText(`${text} ${window.location.href}`);
      alert("Copied to clipboard!");
    }
  };

  const matchesSearch = (terms: string[]) => {
    const query = searchQuery.toLowerCase().trim();
    if (!query) return true;
    return terms.some(term => term.toLowerCase().includes(query));
  };

  return (
    <div className="w-full min-h-screen bg-slate-50 flex items-center justify-center font-sans overflow-hidden">
      <div className="w-full max-w-[400px] h-[100dvh] sm:h-[720px] bg-white sm:rounded-[3rem] sm:shadow-2xl sm:border-[12px] border-slate-900 relative overflow-hidden flex flex-col">
        {/* Status Bar (decorative for theme) */}
        <div className="hidden sm:flex h-10 px-8 pt-4 justify-between items-center">
          <span className="text-xs font-bold">12:45</span>
          <div className="flex gap-1.5">
            <div className="w-4 h-4 rounded-full border-2 border-slate-900 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-slate-900 rounded-full"></div>
            </div>
            <div className="w-4 h-4 bg-slate-900 rounded-sm"></div>
          </div>
        </div>

        {/* Header */}
        <div className="px-8 py-6 pb-2 flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-black text-slate-900 leading-tight">BW Wallet Hub</h1>
            <p className="text-slate-500 text-sm">Instant USSD shortcuts for Botswana.</p>
          </div>
          {deferredPrompt && (
            <button 
              onClick={handleInstall}
              className="flex items-center gap-1.5 bg-slate-900 text-white px-3 py-1.5 rounded-full text-xs font-bold hover:bg-slate-800 transition-colors shadow-sm shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install</span>
            </button>
          )}
        </div>

        {/* Search Bar */}
        <div className="px-6 mt-4 relative z-10 shrink-0">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search wallets..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 border-none rounded-2xl py-3 pl-11 pr-4 text-sm font-bold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-300 transition-all"
            />
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
              <Search className="w-4 h-4" strokeWidth={3} />
            </div>
          </div>
        </div>

        {/* Content / Wallet Grid */}
        <div className="flex-1 px-6 space-y-4 mt-4 overflow-y-auto z-10 relative">
          
          {/* Orange Money */}
          {matchesSearch(['Orange Money', 'Orange', '*145#']) && (
            <div className="relative group bg-[#FF7900] rounded-3xl p-5 shadow-lg shadow-orange-200 border-b-4 border-orange-700 active:translate-y-1 active:border-b-0 transition-all">
              <a href="tel:*145%23" className="absolute inset-0 z-0 rounded-3xl" aria-label="Dial Orange Money *145#"></a>
              <div className="relative z-10 flex items-center justify-between pointer-events-none">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-inner overflow-hidden transform group-hover:scale-105 transition-transform p-1">
                    <div className="relative w-full h-full rounded-xl overflow-hidden">
                      <Image src="/1776993994638.jpg" alt="Orange Money" fill className="object-cover" referrerPolicy="no-referrer" />
                    </div>
                  </div>
                  <div>
                    <h2 className="text-white font-bold text-lg">Orange Money</h2>
                    <p className="text-orange-100 text-xs font-medium">Press to dial *145#</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 pointer-events-auto">
                  <button 
                    onClick={(e) => handleShare(e, 'Orange Money', '*145#')}
                    className="bg-white/10 hover:bg-white/30 transition-colors p-2 rounded-full cursor-pointer"
                    title="Share Orange Money code"
                  >
                    <Share2 className="w-5 h-5 text-white" />
                  </button>
                  <div className="bg-white/20 p-2 rounded-full">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Smega */}
          {matchesSearch(['BTC Smega', 'BTC', 'Smega', '*180#']) && (
            <div className="relative group bg-[#2ECC71] rounded-3xl p-5 shadow-lg shadow-emerald-100 border-b-4 border-emerald-700 active:translate-y-1 active:border-b-0 transition-all">
              <a href="tel:*180%23" className="absolute inset-0 z-0 rounded-3xl" aria-label="Dial BTC Smega *180#"></a>
              <div className="relative z-10 flex items-center justify-between pointer-events-none">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-inner overflow-hidden transform group-hover:scale-105 transition-transform p-1">
                    <div className="relative w-full h-full rounded-xl overflow-hidden">
                      <Image src="/1776994178817.jpg" alt="BTC Smega" fill className="object-cover" referrerPolicy="no-referrer" />
                    </div>
                  </div>
                  <div>
                    <h2 className="text-white font-bold text-lg">BTC Smega</h2>
                    <p className="text-emerald-500 text-xs font-medium bg-white px-2 py-0.5 rounded-full inline-block mt-0.5">Press to dial *180#</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 pointer-events-auto">
                  <button 
                    onClick={(e) => handleShare(e, 'BTC Smega', '*180#')}
                    className="bg-white/10 hover:bg-white/30 transition-colors p-2 rounded-full cursor-pointer"
                    title="Share BTC Smega code"
                  >
                    <Share2 className="w-5 h-5 text-white" />
                  </button>
                  <div className="bg-white/20 p-2 rounded-full">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* MyZaka */}
          {matchesSearch(['Mascom MyZaka', 'Mascom', 'MyZaka', '*167#']) && (
            <div className="relative group bg-[#FFD700] rounded-3xl p-5 shadow-lg shadow-yellow-100 border-b-4 border-yellow-600 active:translate-y-1 active:border-b-0 transition-all">
              <a href="tel:*167%23" className="absolute inset-0 z-0 rounded-3xl" aria-label="Dial Mascom MyZaka *167#"></a>
              <div className="relative z-10 flex items-center justify-between pointer-events-none">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center shadow-inner overflow-hidden transform group-hover:scale-105 transition-transform p-1">
                   <div className="relative w-full h-full rounded-xl overflow-hidden">
                      <Image src="/1776994127175.jpg" alt="Mascom MyZaka" fill className="object-cover" referrerPolicy="no-referrer" />
                    </div>
                  </div>
                  <div>
                    <h2 className="text-slate-900 font-bold text-lg">Mascom MyZaka</h2>
                    <p className="text-slate-700 text-xs font-medium">Press to dial *167#</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 pointer-events-auto">
                  <button 
                    onClick={(e) => handleShare(e, 'Mascom MyZaka', '*167#')}
                    className="bg-slate-900/5 hover:bg-slate-900/10 transition-colors p-2 rounded-full cursor-pointer"
                    title="Share Mascom MyZaka code"
                  >
                    <Share2 className="w-5 h-5 text-slate-900" />
                  </button>
                  <div className="bg-slate-900/10 p-2 rounded-full">
                    <Phone className="w-6 h-6 text-slate-900" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Setup Info Area */}
          <div className="mt-6 bg-slate-100 rounded-2xl p-5 border border-slate-200 flex gap-4">
            <div className="w-10 h-10 bg-white rounded-full flex shrink-0 items-center justify-center shadow-sm border border-slate-200">
              <Info className="h-5 w-5 text-slate-600" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 mb-1">How it works</h3>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                Tap on any wallet to instantly open your phone&apos;s dialer with the USSD code pre-filled. Just hit the call button!
              </p>
            </div>
          </div>
        </div>

        {/* Quick Stats / Footer */}
        <div className="px-6 py-6 pb-8 z-10 relative mt-auto">
          <div className="bg-slate-100 rounded-2xl p-4 flex justify-around border border-slate-200">
            <div className="text-center">
              <div className="text-xs text-slate-400 uppercase font-bold tracking-widest">Wallets</div>
              <div className="text-slate-900 font-black italic">3 Active</div>
            </div>
            <div className="w-px bg-slate-200"></div>
            <div className="text-center">
              <div className="text-xs text-slate-400 uppercase font-bold tracking-widest">Network</div>
              <div className="text-slate-900 font-black italic underline decoration-yellow-400">Ready</div>
            </div>
          </div>
        </div>

        {/* Navigation Pill (desktop decoration) */}
        <div className="hidden sm:block h-2 w-24 bg-slate-200 rounded-full mx-auto mb-6 z-10 relative"></div>

        {/* Background Decoration */}
        <div className="absolute top-20 right-40 w-64 h-64 bg-orange-200 rounded-full blur-[100px] opacity-40 z-0"></div>
        <div className="absolute bottom-20 left-40 w-64 h-64 bg-emerald-200 rounded-full blur-[100px] opacity-40 z-0"></div>
      </div>
    </div>
  );
}
